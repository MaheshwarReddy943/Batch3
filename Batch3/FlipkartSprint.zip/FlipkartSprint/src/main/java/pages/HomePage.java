package pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.Test_base;
import util.TestUtil;

public class HomePage extends Test_base {
	@FindBy(xpath = "//img[@title='Flipkart']")
	WebElement fliplogo;

	@FindBy(xpath = "//input[@placeholder='Search for products, brands and more']")
	WebElement searchbar;

	@FindBy(xpath = "//div[contains(text(),'My Account')]")
	WebElement account;

	@FindBy(xpath = "//div[@class='exehdJ'][normalize-space()='More']")
	WebElement more;

	@FindBy(xpath = "//span[normalize-space()='Cart']")
	WebElement cartbt;

	@FindBy(xpath = "//input[@name=\"q\"]")
	WebElement searchitem;

	@FindBy(xpath = "//img[@alt='Beauty, Toys & More']")
	WebElement beauty;

	@FindBy(xpath = "//a[normalize-space()='Safety & Hygiene Essentials']")
	WebElement safe;

	@FindBy(xpath = "//a[normalize-space()='Sanitizers']")
	WebElement sanitizer;

	// Initializing the Page Objects
	public HomePage(WebDriver wd) {
		PageFactory.initElements(wd, this);

	}

	public String getTitleofPage() {
		return driver.getTitle();

	}

	public boolean Logo() {

		return fliplogo.isDisplayed();
	}

	public boolean Search() {

		return searchbar.isEnabled();
	}

	public boolean MyAccountlink() {

		return account.isEnabled();
	}

	public boolean Morelink() {

		return more.isEnabled();
	}

	public boolean Cart() {

		return cartbt.isEnabled();
	}


	public void searchAny(String search) throws Exception {
		Thread.sleep(3000);
		searchitem.sendKeys(search + Keys.ENTER);
		
	}

	public void clickOnSanitizers() throws InterruptedException {
		Actions action = new Actions(driver);
		Thread.sleep(3000);
		action.moveToElement(beauty).build().perform();
		action.moveToElement(safe).build().perform();
		sanitizer.click();
		

	}

}
