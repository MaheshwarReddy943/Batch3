package pages;

import base.Test_base;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import pages.HomePage;

public class LoginPage extends Test_base {
	@FindBy(xpath = "//input[@class='_2IX_2- VJZDxU']")
	WebElement emailorphone;

	@FindBy(xpath = "//input[@type='password']")
	WebElement password;

	@FindBy(xpath = "//button[@class='_2KpZ6l _2HKlqd _3AWRsL']")
	WebElement loginbtn;

	@FindBy(xpath = "//a[@class='_2QKxJ- _2_DUc_']//span[contains(text(),'Forgot?')]")
	WebElement forgotpwd;

	@FindBy(xpath = "//button[@class='_2KpZ6l _2HKlqd _3NgS1a'][contains(text(),'Request OTP')]")
	WebElement reqotp;

	@FindBy(xpath = "//a[contains(text(),'New to Flipkart? Create an account')]")
	WebElement register;

	@FindBy(xpath = "//span[@class='_36KMOx']//span[contains(text(),'Login')]")
	WebElement loginname;

	@FindBy(xpath = "//span[contains(text(),'Your username or password is incorrect')]")
	WebElement msg;

	// Initializing the Page Objects
	public LoginPage(WebDriver wd) {
		PageFactory.initElements(wd, this);

	}

	// get title
	public String getTitleofPage() {
		String title = driver.getTitle();
		return title;
	}

	// validate forgot password link
	public boolean Forgotpwd() {

		return forgotpwd.isEnabled();
	}

//	validate request OTP link
	public boolean RequestOTP() {

		return reqotp.isEnabled();
	}

	// validate new user/register link
	public boolean Register() {

		return register.isEnabled();
	}

	public boolean logintext() throws Exception {
		return loginname.isDisplayed();
	}

	// valid login credentials
	public HomePage validateLogin(String phn, String pwd) {
		emailorphone.sendKeys(phn);
		password.sendKeys(pwd);
		loginbtn.click();
		return new HomePage(driver);
	}

	// invalid login credentials
	public String InvalidateLogin(String phnIN, String pwdIN) {
		emailorphone.sendKeys(phnIN);
		password.sendKeys(pwdIN);
		loginbtn.click();
		return msg.getText();
	}

}
