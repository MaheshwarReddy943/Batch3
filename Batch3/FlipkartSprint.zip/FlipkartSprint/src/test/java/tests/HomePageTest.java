package tests;

import org.apache.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import base.Test_base;
import junit.framework.Assert;
import pages.HomePage;
import pages.LoginPage;

public class HomePageTest extends Test_base {
	HomePage homePage;
	Logger log = Logger.getLogger(LoginTest.class);

	public HomePageTest() {
		super();
	}

	@BeforeMethod
	public void setUp() throws Exception {
		log.info(
				"****************************** Starting test cases execution in HomePageTest *****************************************");
		intialization();
		LoginPage login = new LoginPage(driver);

		homePage = login.validateLogin(prop.getProperty("phone"), prop.getProperty("password"));
	}

	@Test(priority = 1)
	public void LoginpageTitle() {
		String homepagetitle = homePage.getTitleofPage();
		Assert.assertEquals(homepagetitle,
				"Online Shopping Site for Mobiles, Electronics, Furniture, Grocery, Lifestyle, Books & More. Best Offers!");

	}

	@Test(priority = 2)
	public void validateLogo() {
		boolean logo = homePage.Logo();
		Assert.assertTrue(logo);
	}

	@Test(priority = 3)
	public void searchbox() {
		log.info("Validate if the search box is enabled or not");
		boolean srch = homePage.Search();
		Assert.assertTrue(srch);

	}

	@Test(priority = 4)
	public void accountlink() {
		log.info("Validate if the My account link is enabled or not");
		boolean accLink = homePage.MyAccountlink();
		Assert.assertTrue(accLink);
	}

	@Test(priority = 5)
	public void morelink() {
		log.info("Validate if the More link is enabled or not");
		boolean homeLink = homePage.Morelink();
		Assert.assertTrue(homeLink);
	}

	@Test(priority = 6)
	public void cartBtns() {
		log.info("Validate if the Cart is enabled or not");
		boolean btn = homePage.Cart();
		Assert.assertTrue(btn);
	}

//	@Test(priority = 5)
//	public void ValidateHomeLinks() throws Exception {
//		List<WebElement> flipkartHomeLinks =driver.findElements(By.xpath("//div[@class='eFQ30H']//a"));
//		List<WebElement> activehomelinks = new ArrayList<WebElement>();
//        for(int i=0;i<flipkartHomeLinks.size();i++) {
//        	if(flipkartHomeLinks.get(i).getAttribute("href")!=null) {
//        		activehomelinks.add(flipkartHomeLinks.get(i));
//        	}
//        }
//        for(int j=0;j<activehomelinks.size();j++) {
//        	HttpURLConnection con=(HttpURLConnection) new URL(activehomelinks.get(j).getAttribute("href")).openConnection();
//        	con.connect();
//        	String response= con.getResponseMessage();
//        	System.out.println(activehomelinks.get(j).getAttribute("href")+"---->"+response);
//        	}
//	}

	@Test(priority = 7)
	public void sreach() throws Exception {
		log.info("Search for a string 'Books' in the search box");
		homePage.searchAny("books");

	}

	@AfterMethod
	public void TearDown() {
		driver.close();
		driver.quit();
	}
}
