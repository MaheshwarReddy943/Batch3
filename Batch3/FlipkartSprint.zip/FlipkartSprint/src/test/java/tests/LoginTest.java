package tests;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import base.Test_base;
import junit.framework.Assert;
import pages.HomePage;
import pages.LoginPage;

public class LoginTest extends Test_base {
	LoginPage login;
	HomePage homepage;
	Logger log = Logger.getLogger(LoginTest.class);
	public LoginTest() {
		super();
	}

	@BeforeMethod
	public void setUp() throws Exception {
		log.info("****************************** Starting test cases execution in LoginTest *****************************************");
		intialization();
		login = new LoginPage(driver);

	}

	@Test(priority = 1)
	public void LoginpageTitle() {
		log.info("Get title of the Login page");
		String loginpagetitle = login.getTitleofPage();
		Assert.assertEquals(loginpagetitle,
				"Online Shopping Site for Mobiles, Electronics, Furniture, Grocery, Lifestyle, Books & More. Best Offers!");
	}

	@Test(priority = 2)
	public void validateLogo() throws Exception {
		boolean logo = login.logintext();
		Assert.assertTrue(logo);
	}

	@Test(priority = 3)
	public void loginPagevalidates() {
		log.info("Logging in with Valid credentials");
		login.validateLogin(prop.getProperty("phone"), prop.getProperty("password"));
	}

	@Test(priority = 4)
	public void ValidateForgotPwdLink() {
		log.info("Validate the forgot password link in login window");
		boolean pwd = login.Forgotpwd();
		Assert.assertTrue(pwd);
	}

	@Test(priority = 5)
	public void validateRequestOTPLink() {
		log.info("Validate the Request OTP link in login window");
		boolean otp = login.RequestOTP();
		Assert.assertTrue(otp);
	}

	@Test(priority = 6)
	public void ValidateRegister() {
		log.info("Validate the New user link in login window");
		boolean reg = login.Register();
		Assert.assertTrue(reg);
	}

	@Test(priority = 7)
	public void loginPageInvalid() {
		log.info("Logging in with Invalid credentials");
		String message = login.InvalidateLogin(prop.getProperty("phoneIN"), prop.getProperty("passwordIN"));
		Assert.assertEquals(message, "Your username or password is incorrect");

	}

	@AfterMethod
	public void TearDown() {
		driver.close();
		driver.quit();
	}
}
